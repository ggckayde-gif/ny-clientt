/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2025 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.features.module.modules.combat.killaura

import net.ccbluex.liquidbounce.config.types.NamedChoice
import net.ccbluex.liquidbounce.utils.aiming.RotationTarget
import net.ccbluex.liquidbounce.utils.aiming.RotationsConfigurable
import net.ccbluex.liquidbounce.utils.aiming.data.Rotation
import net.ccbluex.liquidbounce.utils.aiming.features.processors.PolarResetFlagsProcessor
import net.ccbluex.liquidbounce.utils.client.RestrictedSingleUseAction
import net.minecraft.entity.Entity

object KillAuraRotationsConfigurable : RotationsConfigurable(ModuleKillAura, combatSpecific = true) {

    val rotationTiming by enumChoice("RotationTiming", KillAuraRotationTiming.NORMAL)
    val aimThroughWalls by boolean("ThroughWalls", false)

    /**
     * Polar Reset Flags: adds a brief polar-coordinate jitter whenever the
     * rotation target resets (new target or snap-back), making the miss pattern
     * harder to fingerprint by server anti-cheat systems.
     */
    private val polarResetFlags = tree(PolarResetFlagsProcessor(ModuleKillAura))

    override fun toRotationTarget(
        rotation: Rotation,
        entity: Entity?,
        considerInventory: Boolean,
        whenReached: RestrictedSingleUseAction?
    ): RotationTarget {
        val base = super.toRotationTarget(rotation, entity, considerInventory, whenReached)
        // Inject PolarResetFlags into the processor pipeline when it is active.
        return if (polarResetFlags.running) {
            RotationTarget(
                base.rotation,
                base.entity,
                base.processors + polarResetFlags,
                base.ticksUntilReset,
                base.resetThreshold,
                base.considerInventory,
                base.movementCorrection,
                base.whenReached
            )
        } else {
            base
        }
    }

    enum class KillAuraRotationTiming(override val choiceName: String) : NamedChoice {
        NORMAL("Normal"),
        SNAP("Snap"),
        ON_TICK("OnTick")
    }

}
