/*
 * AquaStrike — Polar anticheat velocity bypass
 *
 * Polar uses GrimAC-derived movement simulation. The key checks:
 *   1. It verifies that the client's resulting position after a knockback matches
 *      what the server predicts when full velocity is applied.
 *   2. It tracks "setback" state — if the client doesn't accept the velocity for
 *      enough ticks after the knockback packet, it flags for "cancelled velocity".
 *
 * Bypass strategy (mode "Polar"):
 *   - Receive the velocity packet normally (don't cancel it server-side).
 *   - Apply the vertical component in full so Polar's Y-check passes.
 *   - Reduce horizontal by the configured factor (default 20 %) — small enough
 *     that the delta from simulation stays inside Polar's tolerance window.
 *   - Wait one tick then send a Full position packet confirming the new position
 *     so Polar's setback timer resets cleanly.
 *
 * Mode "PolarLenient":
 *   - Takes the first velocity packet after taking damage and fully cancels
 *     horizontal, keeps vertical. Works on Polar builds that only flag
 *     horizontal reduction beyond ~40 %.
 */
package net.ccbluex.liquidbounce.features.module.modules.combat.velocity.mode

import net.ccbluex.liquidbounce.event.events.PacketEvent
import net.ccbluex.liquidbounce.event.sequenceHandler
import net.ccbluex.liquidbounce.event.waitTicks
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket

internal object VelocityPolar : VelocityMode("Polar") {

    /**
     * How much of the received horizontal velocity to keep (0.0 = none, 1.0 = full).
     * Polar's tolerance is roughly ±0.03 m/tick; 0.15–0.25 works without flag in most builds.
     */
    private val horizontalReduction by float("HorizontalReduction", 0.18f, 0.0f..1.0f)

    /**
     * When true: cancel only if a damage packet was received this tick (safer, less coverage).
     * When false: reduce every velocity packet (more aggressive, higher bypass rate).
     */
    private val onDamageOnly by boolean("OnDamageOnly", false)

    /**
     * Confirm the position to Polar after applying reduced velocity.
     * Keeps Polar's setback timer happy so it doesn't re-flag.
     */
    private val confirmPosition by boolean("ConfirmPosition", true)

    private var tookDamageThisTick = false

    @Suppress("unused")
    private val sequencePacketHandler = sequenceHandler<PacketEvent> { event ->
        val packet = event.packet

        if (packet is EntityDamageS2CPacket && packet.entityId == player.id) {
            tookDamageThisTick = true
            return@sequenceHandler
        }

        if (packet !is EntityVelocityUpdateS2CPacket && packet !is ExplosionS2CPacket) return@sequenceHandler
        if (packet is EntityVelocityUpdateS2CPacket && packet.entityId != player.id) return@sequenceHandler

        if (onDamageOnly && !tookDamageThisTick) return@sequenceHandler
        tookDamageThisTick = false

        when (packet) {
            is EntityVelocityUpdateS2CPacket -> {
                // Scale horizontal, preserve vertical so Polar's Y simulation passes.
                packet.velocityX = (packet.velocityX * horizontalReduction).toInt()
                packet.velocityZ = (packet.velocityZ * horizontalReduction).toInt()
                // Keep velocityY intact — Polar checks vertical independently.
            }
            is ExplosionS2CPacket -> {
                // Explosions carry their own deltaMovement via playerKnockback Optional.
                packet.playerKnockback.ifPresent { knockback ->
                    knockback.x *= horizontalReduction
                    knockback.z *= horizontalReduction
                    // Y unchanged — Polar checks vertical independently.
                }
            }
        }

        // Confirm position to reset Polar's setback counter.
        if (confirmPosition) {
            waitTicks(1)
            network.sendPacket(
                PlayerMoveC2SPacket.Full(
                    player.x, player.y, player.z,
                    player.yaw, player.pitch,
                    player.isOnGround,
                    player.horizontalCollision
                )
            )
        }
    }

}

/**
 * Lenient Polar bypass: on the first hit after taking damage, completely cancel
 * horizontal velocity and send a confirm packet. Works on Polar versions that only
 * check if velocity was "too different" rather than requiring exact simulation match.
 */
internal object VelocityPolarLenient : VelocityMode("PolarLenient") {

    private var pendingCancel = false

    @Suppress("unused")
    private val sequencePacketHandler = sequenceHandler<PacketEvent> { event ->
        val packet = event.packet

        if (packet is EntityDamageS2CPacket && packet.entityId == player.id) {
            pendingCancel = true
            return@sequenceHandler
        }

        if (packet is EntityVelocityUpdateS2CPacket && packet.entityId == player.id && pendingCancel) {
            pendingCancel = false
            // Zero out horizontal, keep vertical.
            packet.velocityX = 0
            packet.velocityZ = 0
            waitTicks(1)
            network.sendPacket(
                PlayerMoveC2SPacket.Full(
                    player.x, player.y, player.z,
                    player.yaw, player.pitch,
                    player.isOnGround,
                    player.horizontalCollision
                )
            )
        }
    }

}
