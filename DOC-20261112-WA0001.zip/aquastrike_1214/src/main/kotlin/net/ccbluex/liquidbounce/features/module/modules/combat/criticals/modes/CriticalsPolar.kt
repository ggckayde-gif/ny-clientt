/*
 * AquaStrike — Criticals bypass for Polar anticheat.
 *
 * Polar checks two things for packet crits:
 *   1. The Y movement deltas look physically plausible given the player's current
 *      fall distance / onGround state.
 *   2. The sequence of positions is internally consistent (no teleportation).
 *
 * This mode sends a micro-displacement downward (≈ 1e-8 blocks) which registers
 * as a falling state in vanilla logic (fallDistance > 0) without triggering
 * Polar's "impossible jump" or "invalid Y delta" checks.
 *
 * Unlike NoCheatPlus mode (0.11 blocks up then back), the displacement here is
 * below Polar's movement-simulation precision threshold (~1e-6 blocks).
 *
 * Use packetType FULL for best compatibility; POSITION_AND_ON_GROUND also works.
 */
package net.ccbluex.liquidbounce.features.module.modules.combat.criticals.modes

import net.ccbluex.liquidbounce.config.types.nesting.Choice
import net.ccbluex.liquidbounce.config.types.nesting.ChoiceConfigurable
import net.ccbluex.liquidbounce.event.events.AttackEntityEvent
import net.ccbluex.liquidbounce.event.handler
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.ModuleCriticals
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.ModuleCriticals.VisualsConfigurable.showCriticals
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.ModuleCriticals.canDoCriticalHit
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.ModuleCriticals.modes
import net.ccbluex.liquidbounce.utils.client.MovePacketType
import net.minecraft.entity.LivingEntity

/**
 * Polar-compatible packet criticals.
 * Sends two Y-displacement packets: one micro-downward (registers fallDistance > 0),
 * one back to onGround=false — both below Polar's simulation-resolution floor.
 */
object CriticalsPolar : Choice("Polar") {

    /**
     * Packet type for the movement packets.
     * FULL includes X/Z so Polar's position cross-check passes.
     */
    private val packetType by enumChoice("PacketType", MovePacketType.FULL)

    /**
     * Size of the micro-displacement in blocks. Keep below 1e-6 to evade
     * Polar's simulation delta check; keep above 0.0 so vanilla counts it
     * as a fall (fallDistance > 0 triggers the critical multiplier).
     */
    private val displacement by float("Displacement", 1.0e-7f, 1.0e-9f..1.0e-4f)

    override val parent: ChoiceConfigurable<Choice>
        get() = modes

    @Suppress("unused")
    private val attackHandler = handler<AttackEntityEvent> { event ->
        if (event.entity !is LivingEntity) return@handler

        val ignoreSprinting = ModuleCriticals.WhenSprinting.shouldAttemptCritWhileSprinting()
        if (!canDoCriticalHit(ignoreOnGround = true, ignoreSprint = ignoreSprinting)) return@handler

        val d = displacement.toDouble()

        // Packet 1: micro-step downward — sets fallDistance > 0 in server simulation.
        sendMovePacket(-d, onGround = false)
        // Packet 2: return to exact Y — confirms we're "falling" by 1 micro-unit.
        sendMovePacket(0.0, onGround = false)

        showCriticals(event.entity)
    }

    private fun sendMovePacket(yOffset: Double, onGround: Boolean) {
        network.sendPacket(packetType.generatePacket().apply {
            y += yOffset
            this.onGround = onGround
        })
    }
}
